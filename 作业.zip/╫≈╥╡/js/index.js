$(function(){
	$(".zhankai").click(function(){
		if($(this).text()=="展开"){
			$(this).children("a").text("收起");
			$(".content").addClass("change");
			$(this).children("img").attr("src","../images/up.png");
		}else{
			$(this).children("a").text("展开");
			$(".content").removeClass("change");
			$(this).children("img").attr("src","../images/bottom.png");
		}
	});

	$(".give_thumbs>span>a").click(function(){
		var num=Number($(this).text());
		   
			$(this).addClass("curr");
			 num++;
		    $(this).text(num);
		    $(this).css("color","red");
			
	});

	$(".give_thumbs>span>small").click(function(){
		$(this).addClass("dele");
		($(this).parent("span").siblings(".content").children("p")).each(function(){

		});
	});

});